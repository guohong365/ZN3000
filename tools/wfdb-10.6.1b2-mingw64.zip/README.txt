file: README			G. Moody	5 May 1999
				Last revised: 22 October 1999

For installation instructions, see `INSTALL' in this directory.
_______________________________________________________________________________
WFDB Software Package:  software for working with annotated signals
Copyright (C) 1999 George B. Moody

The WFDB library (within the lib subdirectory) is free software; you can
redistribute it and/or modify it under the terms of the GNU Library General
Public License as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

The programs in the other subdirectories of this one are also free software;
you can redistribute them and/or modify them under the terms of the GNU General
Public License as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This software is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License, or the
GNU Library General Public License, for more details.

You should have received a copy of the GNU General Public License along with
these programs (see 'COPYING' in this directory).  You should also have
received a copy of the GNU Library General Public License along with the WFDB
library (see 'COPYING.LIB' in the lib subdirectory).  If you did not receive
copies of both of these licenses, see <http://www.gnu.org/licenses/>.

You may contact the author by e-mail (wfdb@physionet.org) or postal mail
(MIT Room E25-505A, Cambridge, MA 02139 USA).  For updates to this software,
please visit http://www.physionet.org/physiotools/.
_______________________________________________________________________________

A note on the licenses for this software:  

You may use (link, incorporate, etc.) the WFDB library with your own programs
and distribute those programs under any terms you wish.  You may also copy and
redistribute unmodified WFDB library sources without restriction.  If you
modify the WFDB library itself, some restrictions apply to how you may
distribute your modified versions.  See the GNU Library General Public License
('COPYING.LIB', in the lib directory) for details.

The intent of these requirements is to encourage the widest possible use of the
WFDB library, by making it possible for you to use the WFDB library in your own
(free or commercial, open source or proprietary) software without payment of
royalties or other "nuisance" restrictions.  Your software is yours; the WFDB
library is a gift with no strings attached, except that, in accordance with the
LGPL, you may not make the library itself proprietary and then attempt to sell
it back to the community that has given it to you.

You may use, copy, and redistribute the WFDB applications, but you must provide
sources for any binaries that you distribute, whether modified or not.  You may
charge a fee to cover the cost of copying and distributing sources and
binaries.  See the GNU General Public License ('COPYING', in this directory)
for details.

Since the WFDB applications are intended to be generally useful to the research
community, the intent is that if you improve them, your improvements should
benefit the community that has given them to you.  You do not have to give away
your improvements; but you may not distribute them at all unless you are
willing to play by the rules spelled out by the GPL.
